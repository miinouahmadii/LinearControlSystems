clc; clear all; close all;

s = tf('s');

A=[0 1 0 0;0 -0.175 3.014 0;0 0 0 1;0 -1.26 50.60 0];
B=[0;0.832;0;6.02];
C=[1 0 0 0;0 0 1 0];
D=[0;0];
[R,Q] = ss2tf(A,B,C,D);
for i=1:2
    TF(i)=minreal(tf(R(i,1:5),Q));
end

controller_e = tf([10 100 1],[1 0]);
controller_f = tf([20 100 1],[1 0]);
G_e = minreal(feedback(1,TF(2)*controller_e));
G_f = minreal(feedback(1,TF(2)*controller_f));
TF = minreal(G_e*TF(1))
figure('Name','??? ?')
impulse(TF)
xlim([0,3])
TF = minreal(G_f*TF(1))
figure('Name','??? ?')
impulse(TF)
grid on; 
