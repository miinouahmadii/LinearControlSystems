clc; clear all; close all;

ab = 42;
M = ab/100;
m = M;
L = 0.3;
I= 0.006;
b = ab/200;
g = 10;
s = tf('s');
G = 1/((-m*L+(m+M)*(I+m*L*L)/(m*L))*s*s +(b*(I+m*L*L)/(m*L))*s-b*g/s-(M+m)*g)

for i = [1 10 20 30 40 50 60 70 80 90]
controller = tf([i 1 1],[1 0]);
TF = feedback(G,controller);
subplot(2,5,floor(i/10)+1)
impulse(TF)
grid on; legend(strcat('K_d = ', num2str(i)),'Location','southwest')
end
