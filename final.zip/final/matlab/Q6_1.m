clc; clear all; close all;

ab = 42;
M = ab/100;
m = M;
L = 0.3;
I= 0.006;
b = ab/200;
g = 10;
s = tf('s');
G = 1/((-m*L+(m+M)*(I+m*L*L)/(m*L))*s*s +(b*(I+m*L*L)/(m*L))*s-b*g/s-(M+m)*g)

k = 1;
z1=-1;
z2=-0.5;
p1=-40;
p2=0;
GC = k*(s-z1)*(s-z2)/((s-p1)*(s-p2))
G = G*GC
rlocus(G)

