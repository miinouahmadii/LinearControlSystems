clc; clear all; close all;

A=[0 1 0 0;0 -0.175 3.014 0;0 0 0 1;0 -1.26 50.60 0];
B=[0;0.832;0;6.02];
C=[1 0 0 0;0 0 1 0];
D=[0;0];
[R,Q] = ss2tf(A,B,C,D);
for i=1:2
    TF(i)=minreal(tf(R(i,1:5),Q));
end

s = tf('s');
k = 75;
z1=-3;
z2=-4;
p1=0;
p2=-50;
GC = k*(s-z1)*(s-z2)/((s-p1)*(s-p2))
G1=TF(1)*(1/(1+TF(1)*GC*k))
impulse(G1)



