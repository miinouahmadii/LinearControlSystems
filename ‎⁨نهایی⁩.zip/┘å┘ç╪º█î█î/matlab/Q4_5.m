clc; clear all; close all;

ab = 42;
M = ab/100;
m = M;
L = 0.3;
I= 0.006;
b = ab/200;
g = 10;
s = tf('s');
G = 1/((-m*L+(m+M)*(I+m*L*L)/(m*L))*s*s +(b*(I+m*L*L)/(m*L))*s-b*g/s-(M+m)*g)

controller = tf([10 100 1],[1 0]);
TF = feedback(G,controller);
impulse(TF)
grid on; 
