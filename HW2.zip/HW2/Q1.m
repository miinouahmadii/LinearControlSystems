close all;

s = tf('s')
c1 = 1
c2 = 1 
tetaref = 1
alpha = 1
M = 1
md = 1

G = 1/(md*c1-md*c2*tetaref+M*c2*alpha+2*md+(M*c1*s))

stepplot(G)



