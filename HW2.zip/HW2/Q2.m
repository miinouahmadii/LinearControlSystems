close all;

syms T(t)

DT = diff(T,t);
D2T = diff(T,t,2);
F = cos(2*t);

m=1;
r=1;
k=2;
a=1;
g=10;
l=1;


A = dsolve(m*r*r*D2T + k*a*a*T + m*g*l*T - F*l, T(0)==0, DT(0)==0);

t=0:0.01:40;
y = subs(A);
plot(t,y)


