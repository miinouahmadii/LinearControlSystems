clear;clc;
close all;

K = 10;

gnum = [K];
gden = [1 1 0];

g = tf(gnum,gden)
Y = feedback(g,1)

stepinfo(Y)
ltiview(Y)
