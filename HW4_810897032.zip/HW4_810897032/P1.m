clear;clc;
close all;

hnum = [3];
hden = [0.2 1];

h = tf(hnum,hden)

stepinfo(h)
ltiview(h)
