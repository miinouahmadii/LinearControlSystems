syms S equation ;
y = 2*S^5+33*S^4+128*S^3+88*S^2+126*S+55==0 %%equation
result2 = solve (y , S); %%solve equation 
double(result2)%%double type for more accuracy
S = -15:0.5:5;
Y = subs(y);

plot(S,Y,'b');
xlabel('S');
ylabel('Y');



