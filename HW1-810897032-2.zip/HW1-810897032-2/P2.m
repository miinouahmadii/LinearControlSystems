syms t s ; 
f1 = (t^2)* exp(-t)* cos(t);
q1_d=laplace(f1,t,s)
syms t1 s ; 
f2 = (sin(4*t1))/t1;
q1_e=laplace(f2,t1,s)



