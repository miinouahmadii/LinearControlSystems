syms t s ;
F1 = ((s+2)*(s+4))/(s*(s+1)*(s+3));
q3_c = ilaplace(F1,s,t)
F2 = (s^2-2)/(s^2+3)^2;
q3_e = ilaplace(F2,s,t)
