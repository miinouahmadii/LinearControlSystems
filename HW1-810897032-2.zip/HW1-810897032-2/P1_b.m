syms x S
y = 2*S^5+33*S^4+128*S^3+88*S^2+126*S+55%%equation
result = solve (y , S); %%solve equation 

fplot(S,y)
xlabel('S');
ylabel('Y');
